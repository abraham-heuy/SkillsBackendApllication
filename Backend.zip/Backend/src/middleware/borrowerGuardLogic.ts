import { Request, Response, NextFunction } from "express";
import pool from "../db/db"; 

export const borrowMiddleware = async (req: Request, res: Response, next: NextFunction) => {
    const { userId, copyId } = req.body;

    if (!userId || !copyId) {
        res.status(400).json({ error: "Missing required fields" });
        return 
    }

    try {
        // Step 1: Check if the user has any pending borrowed books
        const pendingBorrow = await pool.query(
            `SELECT COUNT(*) AS count FROM borrowers 
             WHERE user_id = $1 AND status = 'Borrowed'`,
            [userId]
        );

        if (pendingBorrow.rows[0]?.count > 0) {
            res.status(403).json({ 
                error: "You cannot borrow a new book until you return the previous one." 
            });
            return 
        }

        // Step 2: Check if the user has already borrowed this specific book copy
        const alreadyBorrowed = await pool.query(
            `SELECT COUNT(*) AS count FROM borrowers 
             WHERE user_id = $1 AND copy_id = $2 AND status = 'Borrowed'`,
            [userId, copyId]
        );

        if (alreadyBorrowed.rows[0]?.count > 0) {
             res.status(403).json({ 
                error: "You have already borrowed this book copy. Please return it first." 
            });
            return
        }

        next(); 

    } catch (error) {
        console.error("Error in borrowMiddleware:", error);
        res.status(500).json({ error: "Internal server error" });
    }
};
