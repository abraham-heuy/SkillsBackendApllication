import express from "express";
import { borrowBook, returnBook, getBorrowedBooks } from "../controllers/borrowersController";
import { protect } from "../middleware/auth/protect";
import { adminGuard, borrowerGuard, librarianGuard } from "../middleware/auth/roleMiddleWare";
import { borrowMiddleware } from "@app/middleware/borrowerGuardLogic";

const router = express.Router();

// Borrow a book
router.post("/borrow",protect, borrowMiddleware,borrowBook);

// Return a book
router.post("/return",protect, returnBook);

// Get all borrowed books
router.get("/borrowed",protect,adminGuard, getBorrowedBooks);

export default router;
